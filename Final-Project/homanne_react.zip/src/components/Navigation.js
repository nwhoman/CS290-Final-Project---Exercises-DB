import React from 'react';
import { Link } from 'react-router-dom';
import '../App.css'; 

function Navigation() {
  return (

    <nav >
       <div id="nav-table">
        
            <p><Link to="/">Home</Link>            <Link to="/add-exercise">Add Exercise</Link></p>
      
        </div>
    </nav>
    
  );
}

export default Navigation;