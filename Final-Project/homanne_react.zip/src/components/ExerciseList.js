import React from 'react';
import Exercise from './Exercise';
import { Link, Navigate, useNavigate} from 'react-router-dom';
import {MdDeleteForever, MdEdit, MdAdd} from 'react-icons/md';


function ExerciseList({ exercises, onDelete, onEdit }) {
    const navigate = useNavigate();
    return (
        <table id="exercises">
            <thead>
                <tr>
                    <th>Exercise</th>
                    <th>Reps</th>
                    <th>Weight</th>
                    <th>Unit</th>
                    <th>Date</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                {exercises.map((exercise, i) => <Exercise exercise={exercise}
                    onDelete={onDelete}
                    onEdit={onEdit}
                    key={i} />)}
            </tbody>
            <tfoot><MdAdd onClick={ () => navigate("/add-exercise")}/> Add New Exercise</tfoot>
            {/*<tfoot><Link to="/add-exercise">Add a new exercise</Link></tfoot>*/}
        </table>
    );
}

export default ExerciseList;
