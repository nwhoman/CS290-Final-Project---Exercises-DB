import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function isDateValid(date) {
    // Test using a regular expression. 
    // To learn about regular expressions see Chapter 6 of the text book
    const format = /^\d\d-\d\d-\d\d$/;
    return format.test(date);
}

function validateEntries(name, reps, weight, unit, date){
    if(name === ""){
        alert("Name cannot be empty")
        //navigate('/add-exercise');
    }else if(reps < "1"){
        alert("Reps cannot be less than 1")
        //navigate('/add-exercise');
    }else if(weight < "1"){
        alert("Weight cannot be less than 1")
        //navigate('/add-exercise');
    }else if(unit !== "lbs" && unit !== "kgs"){
        alert("Unit has to be lbs or kgs")
        //navigate('/add-exercise');
    }else if(!isDateValid(date)){
        alert("date has to be MM-DD-YY format")
        //navigate('/add-exercise');
    }else{
        return true
    }}

export const EditExercisePage = ({exerciseToEdit}) => {
    const [name, setName] = useState(exerciseToEdit.name);
    const [reps, setReps] = useState(exerciseToEdit.reps);
    const [weight, setWeight] = useState(exerciseToEdit.weight);
    const [unit, setUnit] = useState(exerciseToEdit.unit);
    const [date, setDate] = useState(exerciseToEdit.date);
    const navigate = useNavigate();  
  

    const editExercise = async () => {
        if (validateEntries(name, reps, weight, unit, date)){

            const editedExerise = {name, reps, weight, unit, date}
        

        const response = await fetch(`/exercises/${exerciseToEdit._id}`, {
            method: 'PUT', 
            body: JSON.stringify(editedExerise),
            headers: {
                'Content-Type': 'application/json',
            },
        })
        if(response.status === 200){
            alert("Successfully edited exercise!");
            
        } else {
            alert(`Failed to edit exercise, status code = ${response.status}`);
        }
        navigate('/');
    }};

    return (
        <div>
            <h2>Edit Exercise</h2>
            <table id="edit-exercise">
            <thead>
                <tr>
                    <th>Exercise</th>
                    <th>Reps</th>
                    <th>Weight</th>
                    <th>Unit</th>
                    <th>Date</th>
                    <th></th>
    
                </tr>
            </thead>
            <tbody>
                <td>
                <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value) }/>
                </td>
                <td>
                <input
                type="number"
                value={reps}
                onChange={e => setReps(e.target.value)} />
                </td>
                <td>
                <input
                type="number"
                value={weight}
                onChange={e => setWeight(e.target.value)} />
                </td>
                <td>
                <select 
                id="unit" 
                name="unit"
                value={unit}
                onChange={e => setUnit(e.target.value)}>
                    <option value="lbs">lbs</option>
                    <option value="kgs">kgs</option>
                </select>
                </td>
                <td>
                <input
                type="text"
                value={date}
                onChange={e => setDate(e.target.value)} />
                </td>
                <td><button
                onClick={editExercise}
            >Save</button></td>
            </tbody></table>
            <div><Link to="/">Return to Main List</Link></div></div>
    );
}

export default EditExercisePage;