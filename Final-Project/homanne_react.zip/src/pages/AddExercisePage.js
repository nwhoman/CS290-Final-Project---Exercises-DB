import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import App from '../App';
import {MdDeleteForever, MdSave, MdAdd, MdHome} from 'react-icons/md';

function isDateValid(date) {
    // Test using a regular expression. 
    // To learn about regular expressions see Chapter 6 of the text book
    const format = /^\d\d-\d\d-\d\d$/;
    return format.test(date);
}

function validateEntries(name, reps, weight, unit, date){
    if(name === ""){
        alert("Name cannot be empty")
        //navigate('/add-exercise');
    }else if(reps < "1"){
        alert("Reps cannot be less than 1")
        //navigate('/add-exercise');
    }else if(weight < "1"){
        alert("Weight cannot be less than 1")
        //navigate('/add-exercise');
    }else if(unit !== "lbs" && unit !== "kgs"){
        alert("Unit has to be lbs or kgs")
        //navigate('/add-exercise');
    }else if(!isDateValid(date)){
        alert("date has to be MM-DD-YY format")
        //navigate('/add-exercise');
    }else{
        return true
    }}

export const AddExercisePage = () => {

    const [name, setName] = useState('');
    const [reps, setReps] = useState('');
    const [weight, setWeight] = useState('');
    const [unit, setUnit] = useState('');
    const [date, setDate] = useState('');
    const navigate = useNavigate();
    //const newExerise = {}

    const addExercise = async () => {
        if(validateEntries(name, reps, weight, unit, date)){
            
             const newExerise = {name, reps, weight, unit, date}

        const response = await fetch('/exercises', {
            method: 'POST', 
            body: JSON.stringify(newExerise),
            headers: {
                'Content-Type': 'application/json',
            },
        })
        if(response.status === 201){
            alert("Successfully added exercise!");
            
        } else {
            alert(`Failed to add exercise, status code = ${response.status}`);
        }
        navigate('/');
    }};

    return (
        <div>
            <h2>Add Exercise</h2>
            <table id="add-exercise">
            <thead>
                <tr>
                    <th>Exercise</th>
                    <th>Reps</th>
                    <th>Weight</th>
                    <th>Unit</th>
                    <th>Date</th>
                    <th></th>
    
                </tr>
            </thead>
            <tbody id="add-exercise-page">
                <tr>
            <td><input
                type="text"
                placeholder="Enter Exercise Name"
                value={name}
                onChange={e => setName(e.target.value)} /></td>
            <td><input
                type="number"
                value={reps}
                placeholder="Enter Reps"
                onChange={e => setReps(e.target.value)} /></td>
            <td><input
                type="number"
                placeholder="Enter Weight"
                value={weight}
                onChange={e => setWeight(e.target.value)} /></td>
            <td>
                <select 
                id="unit" 
                name="unit"
                value={unit}
                onChange={e => setUnit(e.target.value)}>
                    <option ></option>
                    <option value="lbs" >lbs</option>
                    <option value="kgs">kgs</option>
                </select></td>
            <td><input
                type="text"
                placeholder="Enter Date"
                value={date}
                onChange={e => setDate(e.target.value)} /></td>
            <td id="add"><MdSave onClick={addExercise}/>  Save</td>
            {/*<td><button onClick={addExercise}>Add</button></td>*/}
            </tr>
            </tbody>
            <tfoot>< MdHome /><Link to="/">Return to Main List</Link></tfoot>
        </table>
        </div>
    );
}

export default AddExercisePage;