import './App.css';
import React, {useState} from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AddExercisePage from './pages/AddExercisePage';
import EditExercisePage from './pages/EditExercisePage';
import Navigation from './components/Navigation';

function App() {
  const [exerciseToEdit, setExerciseToEdit] = useState();

  return (
    <div className="App">
      
      <header>
        <h1>Exercise Tracker</h1>
        <p>Use this exercise tracker to maintain a list of your favorite exercises and the amount you are capable of lifting.</p>
        
      </header>
      <Router>
        <div className="App-header">
        <Navigation />
		    <Routes>
          <Route path="/" element={<HomePage setExerciseToEdit={setExerciseToEdit}/>}/>
          <Route path="/add-exercise" element={<AddExercisePage />}/>
          <Route path="/edit-exercise" element={ <EditExercisePage exerciseToEdit={exerciseToEdit}/>}/>
		    </Routes>
          </div>
      </Router>
      <footer>
        (c) 2022 Neal Homan
      </footer>
    </div>
  );
}


export default App;